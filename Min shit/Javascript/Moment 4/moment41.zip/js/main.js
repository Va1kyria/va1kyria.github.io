/*
I denna fil lägger du din JavaScript-kod för att lösa uppgiften.
*/