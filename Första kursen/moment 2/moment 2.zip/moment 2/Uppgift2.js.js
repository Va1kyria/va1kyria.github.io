/*Uppgift 2, Creating a function that multiplies 2 numbers and prints
-By Mikaela frendin*/

"use strict";

function multiply(num1, num2) {
    let result = (num1 * num2); //Tells the function how to multiply
    console.log(result);
};

multiply(5, 7);
