/*Uppgift 1, to create variables with forname, lastname and email
-By Mikaela frendin*/

"use strict";

let forname = "Mikaela"; 
let lastname = "Frendin"; 
let email = "mikla86@gmail.com"; 

console.log(forname + " " + lastname + ", " + email);

